import { Notice, Event, Result, Enquiry, AdmissionApplication } from '../types';

// Initial Mock Data
const INITIAL_NOTICES: Notice[] = [
  { id: '1', title: 'Admissions Open for Session 2024-25', date: '2024-03-01', isImportant: true },
  { id: '2', title: 'Annual Sports Day scheduled for April 15th', date: '2024-03-10', isImportant: false },
  { id: '3', title: 'Parent Teacher Meeting on March 30th', date: '2024-03-20', isImportant: false },
];

const INITIAL_EVENTS: Event[] = [
  { id: '1', title: 'Science Exhibition', date: '2024-02-28', description: 'Showcasing innovative projects by our students.', image: 'https://picsum.photos/400/300?random=1' },
  { id: '2', title: 'Annual Function', date: '2023-12-15', description: 'A night of music, dance, and drama.', image: 'https://picsum.photos/400/300?random=2' },
  { id: '3', title: 'Republic Day Celebration', date: '2024-01-26', description: 'Flag hoisting and cultural program.', image: 'https://picsum.photos/400/300?random=3' },
];

// Helper to get/set from localStorage
const getStorage = <T,>(key: string, initial: T): T => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : initial;
  } catch {
    return initial;
  }
};

const setStorage = <T,>(key: string, data: T) => {
  localStorage.setItem(key, JSON.stringify(data));
};

export const storageService = {
  // Notices
  getNotices: () => getStorage<Notice[]>('tss_notices', INITIAL_NOTICES),
  addNotice: (notice: Notice) => {
    const notices = getStorage<Notice[]>('tss_notices', INITIAL_NOTICES);
    setStorage('tss_notices', [notice, ...notices]);
  },
  deleteNotice: (id: string) => {
    const notices = getStorage<Notice[]>('tss_notices', INITIAL_NOTICES);
    setStorage('tss_notices', notices.filter(n => n.id !== id));
  },

  // Events
  getEvents: () => getStorage<Event[]>('tss_events', INITIAL_EVENTS),
  addEvent: (event: Event) => {
    const events = getStorage<Event[]>('tss_events', INITIAL_EVENTS);
    setStorage('tss_events', [event, ...events]);
  },
  deleteEvent: (id: string) => {
    const events = getStorage<Event[]>('tss_events', INITIAL_EVENTS);
    setStorage('tss_events', events.filter(e => e.id !== id));
  },

  // Results
  getResults: () => getStorage<Result[]>('tss_results', []),
  addResult: (result: Result) => {
    const results = getStorage<Result[]>('tss_results', []);
    setStorage('tss_results', [result, ...results]);
  },
  deleteResult: (id: string) => {
    const results = getStorage<Result[]>('tss_results', []);
    setStorage('tss_results', results.filter(r => r.id !== id));
  },

  // Enquiries
  getEnquiries: () => getStorage<Enquiry[]>('tss_enquiries', []),
  addEnquiry: (enquiry: Enquiry) => {
    const list = getStorage<Enquiry[]>('tss_enquiries', []);
    setStorage('tss_enquiries', [enquiry, ...list]);
  },

  // Admissions
  getAdmissions: () => getStorage<AdmissionApplication[]>('tss_admissions', []),
  addAdmission: (app: AdmissionApplication) => {
    const list = getStorage<AdmissionApplication[]>('tss_admissions', []);
    setStorage('tss_admissions', [app, ...list]);
  },
};