export interface Notice {
  id: string;
  title: string;
  date: string;
  isImportant: boolean;
}

export interface Event {
  id: string;
  title: string;
  date: string;
  description: string;
  image: string;
}

export interface Result {
  id: string;
  title: string;
  className: string;
  year: string;
  pdfUrl: string; // simulated
}

export interface Enquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  date: string;
}

export interface AdmissionApplication {
  id: string;
  studentName: string;
  parentName: string;
  phone: string;
  email: string;
  grade: string;
  status: 'pending' | 'reviewed';
  date: string;
}

export enum UserRole {
  GUEST = 'guest',
  ADMIN = 'admin'
}