import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Users, Award, Shield, ChevronLeft, ChevronRight, Calendar, Bell } from 'lucide-react';
import { storageService } from '../services/storage';
import { Notice, Event } from '../types';

const Hero = () => {
  return (
    <div className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/1920/1080?random=10" 
          alt="School Campus" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-navy-900/90 to-navy-900/40"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center sm:text-left pt-20">
        <h1 className="text-4xl sm:text-6xl font-heading font-bold text-white mb-6 leading-tight drop-shadow-lg">
          Shaping Future Leaders <br/>
          <span className="text-accent">Since 1995</span>
        </h1>
        <p className="text-lg sm:text-xl text-gray-200 mb-10 max-w-2xl leading-relaxed">
          Welcome to The Study School, Aspur. We provide a world-class education with a focus on holistic development, innovation, and values.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Link 
            to="/admissions" 
            className="px-8 py-4 bg-accent hover:bg-green-600 text-white rounded-full font-semibold text-lg transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1 flex items-center justify-center gap-2"
          >
            Admissions Open <ArrowRight size={20} />
          </Link>
          <Link 
            to="/contact" 
            className="px-8 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/30 rounded-full font-semibold text-lg transition-all flex items-center justify-center"
          >
            Contact Us
          </Link>
        </div>
      </div>

      {/* Scroll Down Indicator */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce hidden sm:block">
        <div className="w-8 h-12 border-2 border-white/30 rounded-full flex justify-center pt-2">
          <div className="w-1 h-3 bg-white rounded-full"></div>
        </div>
      </div>
    </div>
  );
};

const NoticeTicker = () => {
  const [notices, setNotices] = useState<Notice[]>([]);

  useEffect(() => {
    setNotices(storageService.getNotices());
  }, []);

  return (
    <div className="bg-navy-900 text-white py-3 relative overflow-hidden flex items-center z-20 shadow-md">
      <div className="absolute left-0 top-0 bottom-0 bg-accent px-4 sm:px-6 z-10 flex items-center font-bold text-sm tracking-wide shadow-right">
        <Bell size={16} className="mr-2 animate-pulse" />
        LATEST NOTICES
      </div>
      <div className="whitespace-nowrap overflow-hidden flex-1 ml-40 sm:ml-48">
        <div className="animate-ticker inline-block">
          {notices.map((notice, index) => (
            <span key={index} className="mx-8 text-sm font-medium opacity-90 hover:opacity-100 transition-opacity cursor-pointer">
              {notice.isImportant && <span className="text-yellow-400 mr-2">★</span>}
              {notice.title} <span className="text-gray-500 text-xs ml-2">({notice.date})</span>
            </span>
          ))}
          {/* Duplicate for infinite loop illusion if needed, strictly simpler here */}
        </div>
      </div>
    </div>
  );
};

const FeatureCard = ({ icon: Icon, title, description }: { icon: any, title: string, description: string }) => (
  <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-b-4 border-transparent hover:border-accent group">
    <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-6 text-navy-800 group-hover:bg-navy-800 group-hover:text-white transition-colors">
      <Icon size={32} />
    </div>
    <h3 className="text-xl font-heading font-bold text-gray-800 mb-3">{title}</h3>
    <p className="text-gray-600 leading-relaxed text-sm">{description}</p>
  </div>
);

const Features = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-navy-900 mb-4">Why Choose The Study School?</h2>
          <div className="w-20 h-1 bg-accent mx-auto rounded-full"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <FeatureCard 
            icon={Users} 
            title="Qualified Faculty" 
            description="Experienced and dedicated educators providing personal attention to every student." 
          />
          <FeatureCard 
            icon={Shield} 
            title="Safe Campus" 
            description="24/7 security surveillance and a nurturing environment for your child's safety." 
          />
          <FeatureCard 
            icon={BookOpen} 
            title="Smart Classes" 
            description="Modern digital classrooms equipped with the latest educational technology." 
          />
          <FeatureCard 
            icon={Award} 
            title="Holistic Growth" 
            description="Focus on sports, arts, and character building alongside academic excellence." 
          />
        </div>
      </div>
    </section>
  );
};

const PrincipalMessage = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-navy-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row">
          <div className="md:w-2/5 h-64 md:h-auto relative">
             <img 
              src="https://picsum.photos/600/800?random=20" 
              alt="Principal" 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6">
              <h4 className="text-white text-xl font-bold font-heading">Dr. Rajesh Kumar</h4>
              <p className="text-accent text-sm">Principal, M.A., B.Ed, PhD</p>
            </div>
          </div>
          <div className="md:w-3/5 p-8 md:p-12 flex flex-col justify-center">
            <h2 className="text-3xl font-heading font-bold text-white mb-6">Principal's Message</h2>
            <div className="space-y-4 text-gray-300 leading-relaxed">
              <p>
                "Education is not the filling of a pail, but the lighting of a fire."
              </p>
              <p>
                At The Study School, we believe in nurturing the unique potential of every child. Our goal is to empower students to become lifelong learners and responsible citizens of tomorrow. We strive to create an environment where traditional values meet modern learning methodologies.
              </p>
              <p>
                I invite you to explore our campus and become a part of our growing family.
              </p>
            </div>
            <div className="mt-8">
               <img src="https://upload.wikimedia.org/wikipedia/commons/e/e4/Signature_sample.svg" alt="Signature" className="h-12 invert opacity-70" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const EventsPreview = () => {
  const [events, setEvents] = useState<Event[]>([]);

  useEffect(() => {
    setEvents(storageService.getEvents().slice(0, 3));
  }, []);

  return (
    <section className="py-20 bg-gray-50">
       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl font-heading font-bold text-navy-900 mb-2">School Happenings</h2>
            <div className="w-20 h-1 bg-accent rounded-full"></div>
          </div>
          <Link to="/about" className="hidden sm:flex items-center text-accent font-semibold hover:text-green-700 transition-colors">
            View All Events <ArrowRight size={18} className="ml-2" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {events.map((event) => (
            <div key={event.id} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all group">
              <div className="h-48 overflow-hidden relative">
                <img src={event.image} alt={event.title} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute top-4 left-4 bg-accent text-white px-3 py-1 rounded-md text-xs font-bold uppercase tracking-wider">
                  Event
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center text-xs text-gray-500 mb-3">
                  <Calendar size={14} className="mr-1" />
                  {event.date}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3 group-hover:text-primary transition-colors">{event.title}</h3>
                <p className="text-gray-600 text-sm line-clamp-2">{event.description}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-8 text-center sm:hidden">
           <Link to="/about" className="inline-flex items-center text-accent font-semibold hover:text-green-700 transition-colors">
            View All Events <ArrowRight size={18} className="ml-2" />
          </Link>
        </div>
      </div>
    </section>
  );
};

const Home = () => {
  return (
    <div className="animate-fade-in">
      <Hero />
      <NoticeTicker />
      <Features />
      <PrincipalMessage />
      <EventsPreview />
    </div>
  );
};

export default Home;