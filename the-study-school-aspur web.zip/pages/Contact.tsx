import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, Loader, CheckCircle } from 'lucide-react';
import { storageService } from '../services/storage';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      storageService.addEnquiry({
        id: Date.now().toString(),
        ...formData,
        date: new Date().toLocaleDateString()
      });
      setIsSubmitting(false);
      setSubmitted(true);
    }, 1500);
  };

  return (
    <div className="pt-20">
      <div className="bg-navy-900 text-white py-16 text-center">
        <h1 className="text-4xl font-heading font-bold">Contact Us</h1>
        <p className="mt-4 text-gray-300">We'd love to hear from you</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div>
            <h2 className="text-2xl font-bold text-navy-900 mb-8">Get In Touch</h2>
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center text-accent mr-4 shrink-0">
                  <MapPin size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-800">School Address</h3>
                  <p className="text-gray-600 mt-1">Aspur, Dungarpur,<br/>Rajasthan, India - 314021</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center text-accent mr-4 shrink-0">
                  <Phone size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-800">Phone Number</h3>
                  <p className="text-gray-600 mt-1">+91 98765 43210</p>
                  <p className="text-gray-600 text-sm">(Mon-Sat, 8:00 AM - 4:00 PM)</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center text-accent mr-4 shrink-0">
                  <Mail size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-800">Email Address</h3>
                  <p className="text-gray-600 mt-1">info@thestudyschool.com</p>
                  <p className="text-gray-600">admissions@thestudyschool.com</p>
                </div>
              </div>

              <div className="flex items-start">
                 <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center text-accent mr-4 shrink-0">
                  <Clock size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-800">Office Hours</h3>
                  <p className="text-gray-600 mt-1">Monday - Saturday: 8:00 AM - 2:00 PM</p>
                  <p className="text-gray-600">Sunday: Closed</p>
                </div>
              </div>
            </div>
          </div>

          {/* Enquiry Form */}
          <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-100">
             {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-10">
                <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Message Sent!</h3>
                <p className="text-gray-600">We will get back to you as soon as possible.</p>
              </div>
            ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <h3 className="text-2xl font-bold text-navy-900">Send us a Message</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Your Name</label>
                <input required type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent outline-none" placeholder="Full Name" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                  <input required type="tel" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent outline-none" placeholder="Mobile Number" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input required type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent outline-none" placeholder="Email Address" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                <textarea required rows={4} value={formData.message} onChange={(e) => setFormData({...formData, message: e.target.value})} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent outline-none" placeholder="How can we help you?"></textarea>
              </div>
              <button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full bg-accent hover:bg-green-600 text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center"
              >
                {isSubmitting ? <Loader className="animate-spin" /> : 'Send Message'}
              </button>
            </form>
            )}
          </div>
        </div>
      </div>
      
      {/* Map Embed */}
      <div className="h-96 w-full bg-gray-200">
        <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3644.256247738243!2d74.025!3d23.955!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3968798365691d1d%3A0x6b80145699b00865!2sAspur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1645425678901!5m2!1sen!2sin" 
            width="100%" 
            height="100%" 
            style={{border:0}} 
            allowFullScreen={true} 
            loading="lazy"
            title="School Location"
          ></iframe>
      </div>
    </div>
  );
};

export default Contact;