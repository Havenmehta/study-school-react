import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Calendar, FileText, Users, LogOut, Trash2, Plus, X } from 'lucide-react';
import { storageService } from '../../services/storage';
import { Notice, Event, Enquiry, AdmissionApplication } from '../../types';

const Dashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'notices' | 'events' | 'enquiries' | 'admissions'>('notices');
  const [notices, setNotices] = useState<Notice[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [admissions, setAdmissions] = useState<AdmissionApplication[]>([]);

  // Form states
  const [showNoticeForm, setShowNoticeForm] = useState(false);
  const [newNotice, setNewNotice] = useState({ title: '', isImportant: false });

  const refreshData = () => {
    setNotices(storageService.getNotices());
    setEvents(storageService.getEvents());
    setEnquiries(storageService.getEnquiries());
    setAdmissions(storageService.getAdmissions());
  };

  useEffect(() => {
    const isAuth = localStorage.getItem('tss_admin_auth');
    if (!isAuth) {
      navigate('/admin/login');
    }
    refreshData();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('tss_admin_auth');
    navigate('/admin/login');
  };

  const handleAddNotice = (e: React.FormEvent) => {
    e.preventDefault();
    storageService.addNotice({
      id: Date.now().toString(),
      title: newNotice.title,
      date: new Date().toISOString().split('T')[0],
      isImportant: newNotice.isImportant
    });
    setNewNotice({ title: '', isImportant: false });
    setShowNoticeForm(false);
    refreshData();
  };

  const handleDeleteNotice = (id: string) => {
    if(confirm('Are you sure?')) {
      storageService.deleteNotice(id);
      refreshData();
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-navy-900 text-white flex-shrink-0 hidden md:flex flex-col">
        <div className="p-6 text-center border-b border-gray-800">
          <h2 className="text-xl font-heading font-bold">Admin Panel</h2>
          <p className="text-xs text-gray-400">The Study School</p>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <button onClick={() => setActiveTab('notices')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'notices' ? 'bg-accent text-white' : 'text-gray-400 hover:bg-white/5'}`}>
            <Bell size={20} /> <span>Notices</span>
          </button>
          <button onClick={() => setActiveTab('events')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'events' ? 'bg-accent text-white' : 'text-gray-400 hover:bg-white/5'}`}>
            <Calendar size={20} /> <span>Events</span>
          </button>
          <button onClick={() => setActiveTab('enquiries')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'enquiries' ? 'bg-accent text-white' : 'text-gray-400 hover:bg-white/5'}`}>
            <Users size={20} /> <span>Enquiries</span>
          </button>
          <button onClick={() => setActiveTab('admissions')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'admissions' ? 'bg-accent text-white' : 'text-gray-400 hover:bg-white/5'}`}>
            <FileText size={20} /> <span>Admissions</span>
          </button>
        </nav>
        <div className="p-4 border-t border-gray-800">
          <button onClick={handleLogout} className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-red-400 hover:bg-red-500/10 transition-colors">
            <LogOut size={20} /> <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {/* Mobile Header */}
        <div className="md:hidden bg-navy-900 text-white p-4 flex justify-between items-center">
          <span className="font-bold">Admin Panel</span>
          <button onClick={handleLogout}><LogOut size={20} /></button>
        </div>

        <div className="p-8">
          <h1 className="text-2xl font-bold text-gray-800 mb-8 capitalize">{activeTab} Management</h1>

          {/* NOTICES TAB */}
          {activeTab === 'notices' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                 <h3 className="font-semibold text-gray-700">All Notices</h3>
                 <button onClick={() => setShowNoticeForm(true)} className="bg-accent text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-green-600 transition-colors">
                   <Plus size={18} /> Add Notice
                 </button>
              </div>

              {/* Add Notice Modal */}
              {showNoticeForm && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
                  <div className="bg-white p-6 rounded-lg w-full max-w-md">
                    <div className="flex justify-between mb-4">
                      <h3 className="font-bold text-lg">New Notice</h3>
                      <button onClick={() => setShowNoticeForm(false)}><X size={20} /></button>
                    </div>
                    <form onSubmit={handleAddNotice}>
                      <div className="mb-4">
                        <label className="block text-sm text-gray-600 mb-1">Notice Content</label>
                        <input type="text" value={newNotice.title} onChange={e => setNewNotice({...newNotice, title: e.target.value})} required className="w-full border p-2 rounded" />
                      </div>
                      <div className="mb-4 flex items-center gap-2">
                        <input type="checkbox" checked={newNotice.isImportant} onChange={e => setNewNotice({...newNotice, isImportant: e.target.checked})} id="imp" />
                        <label htmlFor="imp" className="text-sm">Mark as Important</label>
                      </div>
                      <button type="submit" className="w-full bg-accent text-white py-2 rounded">Publish</button>
                    </form>
                  </div>
                </div>
              )}

              <div className="bg-white rounded-lg shadow overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Content</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {notices.map(n => (
                      <tr key={n.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{n.date}</td>
                        <td className="px-6 py-4 text-sm text-gray-900 flex items-center">
                          {n.isImportant && <span className="bg-red-100 text-red-800 text-xs px-2 py-0.5 rounded mr-2">Imp</span>}
                          {n.title}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          <button onClick={() => handleDeleteNotice(n.id)} className="text-red-600 hover:text-red-900"><Trash2 size={18} /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ADMISSIONS TAB */}
          {activeTab === 'admissions' && (
             <div className="bg-white rounded-lg shadow overflow-hidden">
               {admissions.length === 0 ? (
                 <div className="p-6 text-center text-gray-500">No applications received yet.</div>
               ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Parent</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Class</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Contact</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {admissions.map(a => (
                        <tr key={a.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{a.studentName}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{a.parentName}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{a.grade}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{a.phone}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{a.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
               )}
            </div>
          )}

          {/* ENQUIRIES TAB */}
          {activeTab === 'enquiries' && (
             <div className="bg-white rounded-lg shadow overflow-hidden">
               {enquiries.length === 0 ? (
                 <div className="p-6 text-center text-gray-500">No enquiries yet.</div>
               ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Message</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {enquiries.map(e => (
                        <tr key={e.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{e.name}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{e.phone}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{e.email}</td>
                          <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">{e.message}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
               )}
            </div>
          )}

          {/* EVENTS TAB (Placeholder for simplicity in this demo) */}
          {activeTab === 'events' && (
            <div className="text-center p-10 bg-white rounded-lg shadow">
              <Calendar className="mx-auto text-gray-300 w-16 h-16 mb-4" />
              <p className="text-gray-500">Event management functionality is similar to Notices.</p>
              <p className="text-gray-400 text-sm mt-2">(Data is read from storageService)</p>
            </div>
          )}

        </div>
      </main>
    </div>
  );
};

export default Dashboard;