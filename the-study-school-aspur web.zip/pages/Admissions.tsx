import React, { useState } from 'react';
import { CheckCircle, FileText, Send, Loader } from 'lucide-react';
import { storageService } from '../services/storage';

const Admissions = () => {
  const [formData, setFormData] = useState({
    studentName: '',
    parentName: '',
    phone: '',
    email: '',
    grade: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      storageService.addAdmission({
        id: Date.now().toString(),
        studentName: formData.studentName,
        parentName: formData.parentName,
        phone: formData.phone,
        email: formData.email,
        grade: formData.grade,
        status: 'pending',
        date: new Date().toLocaleDateString()
      });
      setIsSubmitting(false);
      setSubmitted(true);
      window.scrollTo(0, 0);
    }, 1500);
  };

  return (
    <div className="pt-20">
       <div className="bg-navy-900 text-white py-16 text-center">
        <h1 className="text-4xl font-heading font-bold">Admissions</h1>
        <p className="mt-4 text-gray-300">Join the The Study School family</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Process Info */}
          <div>
            <h2 className="text-2xl font-bold text-navy-900 mb-8">Admission Process</h2>
            <div className="space-y-8 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gray-200 before:z-0">
              
              <div className="relative z-10 flex items-start group">
                <div className="h-10 w-10 bg-accent rounded-full flex items-center justify-center text-white font-bold shrink-0 border-4 border-white shadow-md">1</div>
                <div className="ml-6 bg-white p-5 rounded-lg shadow-sm border border-gray-100 w-full hover:shadow-md transition-shadow">
                  <h3 className="font-bold text-lg mb-1">Registration</h3>
                  <p className="text-gray-600 text-sm">Fill out the online enquiry form or visit the school office to register your child.</p>
                </div>
              </div>

              <div className="relative z-10 flex items-start group">
                <div className="h-10 w-10 bg-white border-2 border-accent text-accent rounded-full flex items-center justify-center font-bold shrink-0 shadow-md">2</div>
                <div className="ml-6 bg-white p-5 rounded-lg shadow-sm border border-gray-100 w-full hover:shadow-md transition-shadow">
                  <h3 className="font-bold text-lg mb-1">Interaction / Test</h3>
                  <p className="text-gray-600 text-sm">For senior classes, a basic written test is conducted. For junior classes, an interaction with parents and the child.</p>
                </div>
              </div>

              <div className="relative z-10 flex items-start group">
                <div className="h-10 w-10 bg-white border-2 border-accent text-accent rounded-full flex items-center justify-center font-bold shrink-0 shadow-md">3</div>
                <div className="ml-6 bg-white p-5 rounded-lg shadow-sm border border-gray-100 w-full hover:shadow-md transition-shadow">
                  <h3 className="font-bold text-lg mb-1">Documentation</h3>
                  <p className="text-gray-600 text-sm">Submit required documents: Birth Certificate, Transfer Certificate, Photos, and Address Proof.</p>
                </div>
              </div>

              <div className="relative z-10 flex items-start group">
                <div className="h-10 w-10 bg-white border-2 border-accent text-accent rounded-full flex items-center justify-center font-bold shrink-0 shadow-md">4</div>
                <div className="ml-6 bg-white p-5 rounded-lg shadow-sm border border-gray-100 w-full hover:shadow-md transition-shadow">
                  <h3 className="font-bold text-lg mb-1">Fee Submission</h3>
                  <p className="text-gray-600 text-sm">Pay the admission fees to confirm the seat.</p>
                </div>
              </div>

            </div>
          </div>

          {/* Form */}
          <div className="bg-gray-50 p-8 rounded-2xl shadow-lg border border-gray-100">
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-10">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle className="w-10 h-10 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Application Submitted!</h3>
                <p className="text-gray-600 mb-8">Thank you for your interest. Our admissions team will contact you shortly.</p>
                <button onClick={() => setSubmitted(false)} className="text-accent font-semibold hover:underline">Submit another application</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="mb-6">
                  <h3 className="text-2xl font-bold text-navy-900">Online Application</h3>
                  <p className="text-gray-500 text-sm">Fill in the details below to start your admission process.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Student Name</label>
                    <input required name="studentName" value={formData.studentName} onChange={handleChange} type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent outline-none transition-all" placeholder="Enter student's name" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Class Applying For</label>
                    <select required name="grade" value={formData.grade} onChange={handleChange} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent outline-none transition-all">
                      <option value="">Select Class</option>
                      <option value="Nursery">Nursery</option>
                      <option value="LKG">LKG</option>
                      <option value="UKG">UKG</option>
                      {[...Array(12)].map((_, i) => (
                        <option key={i} value={`Class ${i + 1}`}>Class {i + 1}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Parent/Guardian Name</label>
                  <input required name="parentName" value={formData.parentName} onChange={handleChange} type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent outline-none transition-all" placeholder="Enter parent's name" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                    <input required name="phone" value={formData.phone} onChange={handleChange} type="tel" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent outline-none transition-all" placeholder="10-digit mobile number" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <input required name="email" value={formData.email} onChange={handleChange} type="email" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent outline-none transition-all" placeholder="your@email.com" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Message (Optional)</label>
                  <textarea name="message" value={formData.message} onChange={handleChange} rows={3} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent outline-none transition-all" placeholder="Any specific queries?"></textarea>
                </div>
                
                <div>
                   <label className="block text-sm font-medium text-gray-700 mb-1">Upload Documents (Optional)</label>
                   <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg hover:border-accent transition-colors cursor-pointer bg-white">
                      <div className="space-y-1 text-center">
                        <FileText className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="flex text-sm text-gray-600">
                          <label className="relative cursor-pointer bg-white rounded-md font-medium text-accent hover:text-green-600 focus-within:outline-none">
                            <span>Upload a file</span>
                            <input type="file" className="sr-only" />
                          </label>
                          <p className="pl-1">or drag and drop</p>
                        </div>
                        <p className="text-xs text-gray-500">PDF, PNG, JPG up to 5MB</p>
                      </div>
                    </div>
                </div>

                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-accent hover:bg-green-600 text-white font-bold py-3 px-4 rounded-lg transition-all shadow-md hover:shadow-lg flex items-center justify-center disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? <Loader className="animate-spin" /> : <span className="flex items-center gap-2">Submit Application <Send size={18} /></span>}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admissions;