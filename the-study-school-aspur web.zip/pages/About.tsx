import React from 'react';
import { Target, Eye, Award } from 'lucide-react';

const About = () => {
  return (
    <div className="pt-20">
      {/* Header */}
      <div className="bg-navy-900 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
             <img src="https://picsum.photos/1920/600?random=12" alt="Background" className="w-full h-full object-cover" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4">About Our School</h1>
          <p className="text-gray-300 max-w-2xl mx-auto">Building foundations for a lifetime of learning and success.</p>
        </div>
      </div>

      {/* Intro */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-heading font-bold text-navy-900 mb-6">Our Legacy of Excellence</h2>
            <p className="text-gray-600 mb-4 leading-relaxed">
              Established in 1995, The Study School in Aspur, Dungarpur has been a pioneer in providing quality education in the region. We combine traditional values with modern teaching methodologies to create a stimulating learning environment.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Our campus is spread over a lush green area, providing a pollution-free and peaceful atmosphere for students. We are committed to the holistic development of every child, ensuring they grow into responsible and capable global citizens.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img src="https://picsum.photos/400/500?random=30" alt="Students" className="rounded-lg shadow-lg w-full h-full object-cover transform translate-y-4" />
            <img src="https://picsum.photos/400/500?random=31" alt="Building" className="rounded-lg shadow-lg w-full h-full object-cover transform -translate-y-4" />
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-md border-t-4 border-accent">
              <Eye className="text-accent mb-4 w-10 h-10" />
              <h3 className="text-xl font-bold mb-3 text-navy-900">Our Vision</h3>
              <p className="text-gray-600">To be a center of excellence in education that nurtures creativity, critical thinking, and character in every student.</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-md border-t-4 border-navy-800">
              <Target className="text-navy-800 mb-4 w-10 h-10" />
              <h3 className="text-xl font-bold mb-3 text-navy-900">Our Mission</h3>
              <p className="text-gray-600">To provide a safe and inclusive learning environment that empowers students to achieve their full potential academically and socially.</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-md border-t-4 border-accent">
              <Award className="text-accent mb-4 w-10 h-10" />
              <h3 className="text-xl font-bold mb-3 text-navy-900">Our Values</h3>
              <p className="text-gray-600">Integrity, Excellence, Respect, and Responsibility are the core pillars that guide our daily interactions and educational approach.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Infrastructure */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-heading font-bold text-navy-900">Infrastructure & Facilities</h2>
            <div className="w-16 h-1 bg-accent mx-auto mt-4 rounded-full"></div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
             {['Science Lab', 'Computer Lab', 'Library', 'Sports Ground', 'Auditorium', 'Smart Classrooms', 'Transport', 'Cafeteria'].map((item, idx) => (
               <div key={idx} className="group relative overflow-hidden rounded-xl shadow-lg aspect-square cursor-pointer">
                 <img src={`https://picsum.photos/400?random=${40+idx}`} alt={item} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                 <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-6">
                   <h3 className="text-white font-bold text-lg">{item}</h3>
                 </div>
               </div>
             ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;