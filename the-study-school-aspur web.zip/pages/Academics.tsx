import React, { useEffect, useState } from 'react';
import { Download, Book, Calendar, Trophy } from 'lucide-react';
import { storageService } from '../services/storage';
import { Result } from '../types';

const Academics = () => {
  const [results, setResults] = useState<Result[]>([]);

  useEffect(() => {
    setResults(storageService.getResults());
  }, []);

  return (
    <div className="pt-20">
      <div className="bg-navy-900 text-white py-16 text-center">
        <h1 className="text-4xl font-heading font-bold">Academics</h1>
        <p className="mt-4 text-gray-300">Nurturing excellence from Nursery to Class XII</p>
      </div>

      {/* Classes and Curriculum */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-2xl font-bold text-navy-900 mb-6 flex items-center">
                <Book className="mr-3 text-accent" /> Academic Structure
              </h2>
              <div className="space-y-6">
                <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-navy-800">
                  <h3 className="font-bold text-lg mb-2">Pre-Primary (Nursery - UKG)</h3>
                  <p className="text-gray-600 text-sm">Play-way method focusing on cognitive and motor skills development through fun activities.</p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-accent">
                  <h3 className="font-bold text-lg mb-2">Primary (Class I - V)</h3>
                  <p className="text-gray-600 text-sm">Foundation building in Mathematics, Languages, and Environmental Sciences.</p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-navy-800">
                  <h3 className="font-bold text-lg mb-2">Middle & Secondary (Class VI - X)</h3>
                  <p className="text-gray-600 text-sm">NCERT curriculum with a focus on conceptual understanding and practical application.</p>
                </div>
              </div>
            </div>
            
            <div>
              <h2 className="text-2xl font-bold text-navy-900 mb-6 flex items-center">
                <Calendar className="mr-3 text-accent" /> Academic Calendar
              </h2>
              <div className="bg-white shadow-lg rounded-xl overflow-hidden border border-gray-100">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Month</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Activity</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200 text-sm text-gray-700">
                    <tr><td className="px-6 py-4 font-medium">April</td><td className="px-6 py-4">New Session Begins</td></tr>
                    <tr><td className="px-6 py-4 font-medium">May</td><td className="px-6 py-4">Unit Test I & Summer Camp</td></tr>
                    <tr><td className="px-6 py-4 font-medium">July</td><td className="px-6 py-4">School Reopens</td></tr>
                    <tr><td className="px-6 py-4 font-medium">September</td><td className="px-6 py-4">Half Yearly Examinations</td></tr>
                    <tr><td className="px-6 py-4 font-medium">December</td><td className="px-6 py-4">Annual Sports Meet</td></tr>
                    <tr><td className="px-6 py-4 font-medium">March</td><td className="px-6 py-4">Annual Examinations</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="text-center mb-12">
            <h2 className="text-3xl font-heading font-bold text-navy-900 flex justify-center items-center gap-3">
              <Trophy className="text-yellow-500" /> Academic Results
            </h2>
            <p className="text-gray-500 mt-2">Download class-wise result sheets</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {results.length > 0 ? (
              results.map((res) => (
                <div key={res.id} className="bg-white p-6 rounded-lg shadow-md flex justify-between items-center hover:shadow-lg transition-shadow">
                  <div>
                    <h4 className="font-bold text-lg text-gray-800">{res.title}</h4>
                    <p className="text-sm text-gray-500">{res.className} • {res.year}</p>
                  </div>
                  <button className="p-2 bg-gray-100 text-navy-900 rounded-full hover:bg-accent hover:text-white transition-colors">
                    <Download size={20} />
                  </button>
                </div>
              ))
            ) : (
              <div className="col-span-full text-center py-8 bg-white rounded-lg border border-dashed border-gray-300 text-gray-500">
                No results published yet. Check back later.
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Academics;